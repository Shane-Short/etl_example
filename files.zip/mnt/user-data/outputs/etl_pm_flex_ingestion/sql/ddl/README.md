# SQL DDL Scripts

This directory contains all database schema creation scripts for the PM Flex pipeline.

## Files

- `00_master_setup.sql` - Master script that runs all others in sequence
- `01_copper_schema.sql` - Copper/Bronze layer (raw data)
- `02_silver_schema.sql` - Silver layer (enriched and aggregated data)
- `03_gold_schema.sql` - Gold layer (KPI and fact tables)

## Usage

### Option 1: Run Master Setup Script (Recommended)

```bash
# Using SQL Server Management Studio (SSMS)
1. Open SSMS and connect to TEHAUSTELSQL1
2. Open 00_master_setup.sql
3. Ensure you're connected to MAData_Output_Production database
4. Execute (F5)

# Using sqlcmd
sqlcmd -S TEHAUSTELSQL1 -d MAData_Output_Production -i 00_master_setup.sql
```

### Option 2: Run Scripts Individually

Execute in this order:
1. `01_copper_schema.sql`
2. `02_silver_schema.sql`
3. `03_gold_schema.sql`

### Option 3: Using Python

```python
from connectors import SQLServerConnector

connector = SQLServerConnector()

# Run all scripts
for script in ['01_copper_schema.sql', '02_silver_schema.sql', '03_gold_schema.sql']:
    connector.execute_script_file(f'sql/ddl/{script}')
```

## Tables Created

### Copper Layer (Bronze)
- `pm_flex_raw` - Raw PM_Flex data (88 columns)
- `pm_flex_load_log` - ETL execution tracking

### Silver Layer
- `pm_flex_enriched` - Enriched PM data with classifications
- `pm_flex_downtime_summary` - Aggregated downtime metrics
- `pm_flex_chronic_tools` - Chronic tool identification
- `DimDate` - Date/work week dimension
- `DimEntity` - Entity/tool dimension

### Gold Layer
- `fact_pm_kpis_by_site_ww` - Site-level KPIs by week
- `fact_pm_kpis_by_ceid_ww` - CEID-level KPIs by week
- `fact_part_replacement_summary` - Part replacement analysis
- `fact_chronic_tools_history` - Historical chronic tool tracking

### Views
- `vw_executive_dashboard_kpis` - Pre-aggregated executive metrics
- `vw_chronic_tools_current` - Current chronic tool status

## Stored Procedures

- `sp_cleanup_pm_flex_copper` - Clean up old copper records (26-week retention)
- `sp_refresh_pm_flex_enriched` - Refresh enriched data from copper
- `sp_calculate_rolling_averages` - Calculate 4-week rolling averages
- `sp_refresh_gold_layer` - Master refresh for all gold layer tables

## Data Retention

- **Copper**: 26 weeks (matches source file)
- **Silver**: Cumulative (2+ years recommended)
- **Gold**: Cumulative (3+ years recommended)

## Indexes

All tables include appropriate indexes for:
- Primary key lookups
- Common filter columns (ENTITY, FACILITY, CEID, dates)
- Join operations
- Sort operations

## Permissions

After running the scripts, grant appropriate permissions:

```sql
-- Grant permissions to service account
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.pm_flex_raw TO [YOUR_SERVICE_ACCOUNT];
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.pm_flex_enriched TO [YOUR_SERVICE_ACCOUNT];
GRANT EXECUTE ON dbo.sp_cleanup_pm_flex_copper TO [YOUR_SERVICE_ACCOUNT];
-- Add other grants as needed
```

## Troubleshooting

### Script Fails on Existing Objects
If tables already exist, the scripts will drop and recreate them. Make sure you have:
1. Backed up any important data
2. Appropriate permissions to DROP tables

### Performance Issues
If you experience slow query performance:
1. Update statistics: `EXEC sp_updatestats`
2. Rebuild indexes: Use maintenance plan or rebuild manually
3. Check execution plans for missing indexes

## Notes

- All timestamps are stored as `DATETIME2` for precision
- Column names with special characters (like parentheses) have been sanitized
- The schema supports both historical and incremental loading patterns
