# Gold Layer ETL

The Gold layer creates analytics-ready KPI fact tables optimized for Power BI dashboards.

## Purpose

Transform silver layer enriched data into pre-aggregated fact tables with:
- Site-level KPIs by work week
- CEID-level KPIs by work week
- Part replacement trends
- Chronic tools historical tracking
- Rolling averages and trends

## Components

### KPIAggregator (`kpi_aggregator.py`)
Main aggregation engine that creates all gold layer fact tables.

## Fact Tables Created

### 1. fact_pm_kpis_by_site_ww
**Purpose**: Site-level KPIs aggregated by work week  
**Grain**: One row per FACILITY + YEARWW  
**Use Case**: Executive dashboard, site performance comparison

**Key Metrics:**
- Total/Scheduled/Unscheduled PM counts
- Early/On-Time/Late/Overdue counts
- Total/Scheduled/Unscheduled downtime hours
- Average/Median PM life vs target
- Unscheduled/Early/On-Time/Overdue rates (%)
- Chronic tools count and percentage
- 4-week rolling averages (PM life, PM count, downtime)

**Example Row:**
```
FACILITY: F10A
YEARWW: 2025WW22
total_pm_events: 1,250
unscheduled_pm_rate: 0.28 (28%)
avg_pm_life: 8,450 wafers
chronic_tools_count: 12
chronic_tools_pct: 0.08 (8%)
rolling_4wk_avg_pm_life: 8,200
```

### 2. fact_pm_kpis_by_ceid_ww
**Purpose**: CEID-level KPIs aggregated by work week  
**Grain**: One row per CEID + FACILITY + YEARWW  
**Use Case**: Chamber-level analysis, CEID comparison

**Key Metrics:**
- Total/Scheduled/Unscheduled PM counts
- Total/Unscheduled downtime hours
- Average/Median/StdDev PM life
- Unscheduled/Early/Overdue rates
- Total chambers and chronic chambers count
- Altair classification flag

**Example Row:**
```
CEID: ETCH_CHAMBER_A
FACILITY: F10A
YEARWW: 2025WW22
AltairFlag: ALTAIR
total_pm_events: 45
unscheduled_pm_rate: 0.31 (31%)
total_chambers: 6
chronic_chambers: 2
```

### 3. fact_part_replacement_summary
**Purpose**: Part replacement trends and analysis  
**Grain**: One row per ATTRIBUTE_NAME + ENTITY + YEARWW  
**Use Case**: Part life optimization, inventory planning

**Key Metrics:**
- Replacement count
- Average/Median/Min/Max wafers at replacement
- Average part life (days)
- Part life variance
- Early/Late replacement counts

**Example Row:**
```
ATTRIBUTE_NAME: Showerhead
ENTITY: GTA453_PC1_C1
YEARWW: 2025WW22
replacement_count: 3
avg_wafers_at_replacement: 12,500
median_wafers_at_replacement: 12,200
early_replacement_count: 1
late_replacement_count: 1
```

### 4. fact_chronic_tools_history
**Purpose**: Historical tracking of chronic tool status  
**Grain**: One row per ENTITY + YEARWW  
**Use Case**: Chronic tools trend analysis, intervention tracking

**Key Metrics:**
- Chronic flag (1/0)
- Chronic score (0-100)
- Chronic severity (Low/Medium/High/Critical)
- Unscheduled PM count and rate
- PM life variance
- Total downtime hours
- Week-over-week chronic score change
- Status changed flag

**Example Row:**
```
ENTITY: GTA453_PC1_C1
YEARWW: 2025WW22
chronic_flag: 1
chronic_score: 78.5
chronic_severity: High
unscheduled_pm_rate: 0.42 (42%)
chronic_score_change: +5.2
status_changed: 0
```

## Data Flow

```
┌───────────────────────────────┐
│ dbo.pm_flex_enriched          │
│ (Silver Layer)                │
│ 50K-200K event-level rows     │
└──────────────┬────────────────┘
               │
               │ Load enriched data
               │ (incremental by work week)
               ▼
┌───────────────────────────────┐
│ KPIAggregator                 │
│                               │
│ 1. Group by FACILITY + WW     │
│ 2. Group by CEID + WW         │
│ 3. Group by PART + WW         │
│ 4. Track chronic tools        │
│ 5. Calculate rolling avgs     │
└──────────────┬────────────────┘
               │
               │ Create fact tables
               ▼
┌───────────────────────────────┐
│ Gold Layer Fact Tables        │
│                               │
│ ┌───────────────────────────┐ │
│ │ fact_pm_kpis_by_site_ww   │ │
│ │ 100-500 rows              │ │
│ │ (1 per site per week)     │ │
│ └───────────────────────────┘ │
│                               │
│ ┌───────────────────────────┐ │
│ │ fact_pm_kpis_by_ceid_ww   │ │
│ │ 500-2,000 rows            │ │
│ │ (1 per CEID per week)     │ │
│ └───────────────────────────┘ │
│                               │
│ ┌───────────────────────────┐ │
│ │ fact_part_replacement_    │ │
│ │ summary                   │ │
│ │ 1,000-5,000 rows          │ │
│ │ (1 per part per entity)   │ │
│ └───────────────────────────┘ │
│                               │
│ ┌───────────────────────────┐ │
│ │ fact_chronic_tools_       │ │
│ │ history                   │ │
│ │ 500-2,000 rows            │ │
│ │ (1 per entity per week)   │ │
│ └───────────────────────────┘ │
└───────────────────────────────┘
               │
               ▼
┌───────────────────────────────┐
│ Power BI Dashboard            │
│ - Executive Overview          │
│ - Site Comparison             │
│ - CEID Analysis               │
│ - Chronic Tools Report        │
│ - Part Life Trends            │
└───────────────────────────────┘
```

## Running the Gold ETL

### Option 1: Incremental (Default)
```bash
# Process only new work weeks
python -m etl.gold.run_gold_etl
```

### Option 2: Work Week Range
```bash
# Process specific work weeks
python -m etl.gold.run_gold_etl --start-ww 2025WW20 --end-ww 2025WW22
```

### Option 3: Full Refresh
```bash
# Truncate and reload all data
python -m etl.gold.run_gold_etl --full-refresh
```

### Option 4: Python Script
```python
from etl.gold.run_gold_etl import run_gold_etl

# Incremental load
stats = run_gold_etl()

# Full refresh
stats = run_gold_etl(full_refresh=True)

# Work week range
stats = run_gold_etl(
    start_ww='2025WW20',
    end_ww='2025WW22',
    incremental=False
)
```

## Configuration

Key settings in `config/config.yaml`:

```yaml
etl:
  gold:
    rolling_window_weeks: 4  # 4-week rolling averages
```

## Key Calculations

### Unscheduled PM Rate
```
unscheduled_pm_rate = unscheduled_pm_count / total_pm_events
```

### Chronic Tools Percentage
```
chronic_tools_pct = chronic_tools_count / total_tools_count
```

### Scheduled vs Unscheduled Downtime
```
scheduled_downtime_hours = total_downtime_hours × (scheduled_pm_events / total_pm_events)
unscheduled_downtime_hours = total_downtime_hours - scheduled_downtime_hours
```

### 4-Week Rolling Averages
```
rolling_4wk_avg_pm_life = AVG(avg_pm_life) OVER (
    PARTITION BY FACILITY 
    ORDER BY ww_year, ww_number 
    ROWS BETWEEN 3 PRECEDING AND CURRENT ROW
)
```

## Monitoring Queries

### Site KPIs - Current Week
```sql
SELECT TOP 10
    FACILITY,
    YEARWW,
    total_pm_events,
    CAST(unscheduled_pm_rate * 100 AS DECIMAL(5,2)) as unscheduled_pct,
    CAST(avg_pm_life AS INT) as avg_wafers,
    chronic_tools_count,
    CAST(chronic_tools_pct * 100 AS DECIMAL(5,2)) as chronic_pct,
    CAST(rolling_4wk_avg_pm_life AS INT) as rolling_avg_wafers
FROM dbo.fact_pm_kpis_by_site_ww
ORDER BY calculation_timestamp DESC;
```

### CEID Performance
```sql
-- Top 10 CEIDs by unscheduled PM rate
SELECT TOP 10
    CEID,
    FACILITY,
    AltairFlag,
    YEARWW,
    total_pm_events,
    CAST(unscheduled_pm_rate * 100 AS DECIMAL(5,2)) as unscheduled_pct,
    chronic_chambers,
    total_chambers
FROM dbo.fact_pm_kpis_by_ceid_ww
WHERE total_pm_events >= 10
ORDER BY unscheduled_pm_rate DESC;
```

### Part Life Analysis
```sql
-- Parts with shortest life
SELECT TOP 20
    ATTRIBUTE_NAME,
    CEID,
    YEARWW,
    replacement_count,
    CAST(avg_wafers_at_replacement AS INT) as avg_wafers,
    early_replacement_count,
    late_replacement_count
FROM dbo.fact_part_replacement_summary
WHERE replacement_count >= 3
ORDER BY avg_wafers_at_replacement ASC;
```

### Chronic Tools Trend
```sql
-- Chronic tools getting worse
SELECT TOP 10
    ENTITY,
    FACILITY,
    YEARWW,
    chronic_score,
    chronic_severity,
    chronic_score_change,
    status_changed
FROM dbo.fact_chronic_tools_history
WHERE chronic_flag = 1
  AND chronic_score_change > 5
ORDER BY chronic_score_change DESC;
```

### Rolling Averages Trend
```sql
-- Site with improving PM life trend
SELECT 
    FACILITY,
    YEARWW,
    CAST(avg_pm_life AS INT) as current_pm_life,
    CAST(rolling_4wk_avg_pm_life AS INT) as rolling_avg,
    CAST((avg_pm_life - rolling_4wk_avg_pm_life) AS INT) as improvement
FROM dbo.fact_pm_kpis_by_site_ww
WHERE rolling_4wk_avg_pm_life IS NOT NULL
ORDER BY FACILITY, ww_year DESC, ww_number DESC;
```

## Power BI Integration

### Connect to Gold Tables

**Connection String:**
```
Server: TEHAUSTELSQL1
Database: MAData_Output_Production
```

**Import Tables:**
1. `fact_pm_kpis_by_site_ww`
2. `fact_pm_kpis_by_ceid_ww`
3. `fact_part_replacement_summary`
4. `fact_chronic_tools_history`
5. `DimDate` (from silver layer)

**Or use views:**
- `vw_executive_dashboard_kpis` (pre-joined)
- `vw_chronic_tools_current` (latest chronic status)

### Recommended Measures (DAX)

```dax
// Total PM Events
Total PMs = SUM(fact_pm_kpis_by_site_ww[total_pm_events])

// Unscheduled PM Rate
Unscheduled PM % = 
    DIVIDE(
        SUM(fact_pm_kpis_by_site_ww[unscheduled_pm_events]),
        SUM(fact_pm_kpis_by_site_ww[total_pm_events]),
        0
    ) * 100

// Average PM Life
Avg PM Life = 
    AVERAGE(fact_pm_kpis_by_site_ww[avg_pm_life])

// Chronic Tools Count
Chronic Tools = 
    SUM(fact_pm_kpis_by_site_ww[chronic_tools_count])

// On-Time PM %
On-Time PM % = 
    DIVIDE(
        SUM(fact_pm_kpis_by_site_ww[on_time_pm_count]),
        SUM(fact_pm_kpis_by_site_ww[total_pm_events]),
        0
    ) * 100

// Rolling Average Trend
PM Life Trend = 
    AVERAGE(fact_pm_kpis_by_site_ww[rolling_4wk_avg_pm_life])
```

### Recommended Relationships

```
DimDate[work_week] → fact_pm_kpis_by_site_ww[YEARWW]
DimDate[work_week] → fact_pm_kpis_by_ceid_ww[YEARWW]
DimDate[work_week] → fact_part_replacement_summary[YEARWW]
DimDate[work_week] → fact_chronic_tools_history[YEARWW]
```

## Performance Metrics

Typical execution:
- **Input**: 50K-200K enriched rows
- **Output**: 
  - Site KPIs: 100-500 rows
  - CEID KPIs: 500-2,000 rows
  - Part Summary: 1,000-5,000 rows
  - Chronic History: 500-2,000 rows
- **Execution Time**: 30-90 seconds
- **Memory Usage**: ~500 MB peak

## Business Value

### Executive Dashboard (Page 1)
✅ Total PM events (current week)
✅ Unscheduled PM rate trend
✅ Average PM life vs target
✅ Chronic tools count and trend
✅ Site performance comparison
✅ 4-week rolling averages

### Site Performance Analysis
✅ Week-over-week comparison
✅ Site rankings by KPIs
✅ Trend identification
✅ Benchmark against targets

### CEID Analysis
✅ Chamber-level performance
✅ Altair vs Non-Altair comparison
✅ CEID-specific chronic tools
✅ Equipment utilization

### Part Life Optimization
✅ Early replacement identification
✅ Part life variance tracking
✅ Inventory planning support
✅ Cost optimization insights

## Troubleshooting

### Issue: No Data to Process
```
Warning: No data to process
```
**Solution:** Ensure silver layer has run and pm_flex_enriched has data.

### Issue: Rolling Averages Not Calculating
```
Warning: Stored procedure failed
```
**Solution:** The system will fall back to Python calculation. Check if sp_calculate_rolling_averages exists.

### Issue: Chronic Tools Count is Zero
```
chronic_tools_count: 0 for all sites
```
**Solution:** 
1. Check pm_flex_chronic_tools table has data
2. Verify chronic_flag = 1 for some entities
3. Ensure silver layer chronic analysis ran successfully

### Issue: Part Summary is Empty
```
No part data to summarize
```
**Solution:** This is normal if ATTRIBUTE_NAME column has many NULLs. Part analysis is optional.

## Next Steps

After gold layer completes:
1. **Verify fact tables**: Query each table to confirm data
2. **Test Power BI connection**: Import gold tables
3. **Build Page 1 dashboard**: Use executive KPIs
4. **Set up refresh schedule**: Weekly Wednesday 7 AM PST

---

**Gold layer provides the analytics foundation for your entire dashboard!** 🎯
