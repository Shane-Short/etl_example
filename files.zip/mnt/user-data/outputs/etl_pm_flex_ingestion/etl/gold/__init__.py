"""
Gold layer ETL modules.

Handles creation of KPI fact tables and aggregations for analytics and reporting.
"""

from .kpi_aggregator import KPIAggregator

__all__ = ["KPIAggregator"]
