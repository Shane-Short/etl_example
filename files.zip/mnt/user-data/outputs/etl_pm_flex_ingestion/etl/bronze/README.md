# Bronze Layer ETL

The Bronze (Copper) layer handles raw data ingestion from PM_Flex CSV files into SQL Server.

## Components

### 1. PMFlexFileDiscovery (`file_discovery.py`)
Discovers PM_Flex files on the network share.

**Features:**
- Scans network share for PM_Flex.csv files
- Uses Intel WW calendar to locate files
- Finds latest file automatically
- Validates file existence and accessibility
- Provides file metadata

**Usage:**
```python
from etl.bronze import PMFlexFileDiscovery

# Initialize
discovery = PMFlexFileDiscovery()

# Find latest file (searches last 4 weeks)
file_path, work_week = discovery.find_latest_file(max_weeks_back=4)

# Find specific week
file_path = discovery.find_file_for_week('2025WW22')

# List all available weeks
weeks = discovery.list_available_weeks()

# Get file info
info = discovery.get_file_info(file_path)
```

### 2. PMFlexRawLoader (`raw_loader.py`)
Loads CSV data into SQL Server copper layer.

**Features:**
- Reads PM_Flex CSV with proper encoding
- Validates schema (88 expected columns)
- Adds metadata columns (load_timestamp, source_file, source_ww)
- Adds Altair classification
- Cleans column names for SQL
- Performs data quality checks
- Logs load execution

**Usage:**
```python
from etl.bronze import PMFlexRawLoader

# Initialize
loader = PMFlexRawLoader()

# Load a file
stats = loader.load_file(
    file_path=Path("\\\\server\\share\\Data\\2025WW22\\PM_Flex.csv"),
    work_week="2025WW22",
    validate_schema=True,
    add_altair=True
)

# Check current row count
row_count = loader.get_row_count()

# Truncate table (caution!)
loader.truncate_table()
```

### 3. Main Orchestration (`run_bronze_etl.py`)
End-to-end bronze layer execution.

**Features:**
- Discovers and loads files in one step
- Comprehensive logging
- Error handling
- Command-line interface

## Running the Bronze ETL

### Option 1: Automatic (Find Latest File)
```bash
# Find and load the most recent file
python -m etl.bronze.run_bronze_etl

# Search up to 8 weeks back
python -m etl.bronze.run_bronze_etl --max-weeks-back 8
```

### Option 2: Specific Work Week
```bash
# Load a specific work week
python -m etl.bronze.run_bronze_etl --work-week 2025WW22 --no-find-latest
```

### Option 3: Python Script
```python
from etl.bronze.run_bronze_etl import run_bronze_etl

# Run with defaults (find latest)
stats = run_bronze_etl()

# Run for specific week
stats = run_bronze_etl(work_week='2025WW22', find_latest=False)
```

## Data Flow

```
Network Share                    SQL Server
├── 2025WW20/                   
│   └── PM_Flex.csv             
├── 2025WW21/                    ┌─────────────────────┐
│   └── PM_Flex.csv     ────────▶│  pm_flex_raw        │
├── 2025WW22/                    │  (88 columns +      │
│   └── PM_Flex.csv              │   metadata +        │
└── 2025WW23/                    │   AltairFlag)       │
    └── PM_Flex.csv              └─────────────────────┘
                                          │
                                          ▼
                                 ┌─────────────────────┐
                                 │  pm_flex_load_log   │
                                 │  (execution track)  │
                                 └─────────────────────┘
```

## Column Transformations

### Metadata Columns Added
- `pm_flex_raw_id` - Auto-increment primary key
- `load_timestamp` - When data was loaded
- `source_file` - Full path to source CSV
- `source_ww` - Work week string (e.g., '2025WW22')

### Altair Classification
- `AltairFlag` - ALTAIR, NON-ALTAIR, MIX, or UNKNOWN
  - Loaded from `data/altair_tools.csv`
  - Joined on ENTITY column

### Column Name Changes
For SQL Server compatibility:
- `EQUIPMENT_DOWNTIME_ROI(Hrs)` → `EQUIPMENT_DOWNTIME_ROI_Hrs`
- `PART_COST_SAVING_ROI($)` → `PART_COST_SAVING_ROI`
- `LABORHOUR_PER_PM.1` → `LABORHOUR_PER_PM_2`
- `LABOR_HOUR_ROI(Hrs)` → `LABOR_HOUR_ROI_Hrs`
- `HEADCOUNT_ROI(#)` → `HEADCOUNT_ROI`

## Data Quality Checks

Performed automatically during load:

1. **Schema Validation**
   - Verify all 88 expected columns present
   - Log any extra columns found

2. **Null Value Analysis**
   - Check critical columns (ENTITY, FACILITY, CEID, YEARWW)
   - Warn if >50% nulls in critical columns
   - Log overall null percentage

3. **Row Count Validation**
   - Compare to previous weeks (±20% tolerance)
   - Log warnings for anomalies

4. **File Size Check**
   - Ensure file is not empty
   - Log file size for tracking

## Error Handling

The bronze layer handles these error scenarios:

- **File Not Found**: Searches up to N weeks back
- **Schema Mismatch**: Lists missing/extra columns
- **Database Connection**: Retries with exponential backoff
- **Data Quality Issues**: Logs warnings but continues
- **Altair Classification Failure**: Sets to UNKNOWN

All errors are logged to:
- Console output
- Log file (`logs/pm_flex_pipeline.log`)
- `pm_flex_load_log` table

## Monitoring

Check load status:
```sql
-- Recent loads
SELECT TOP 10 *
FROM dbo.pm_flex_load_log
ORDER BY load_timestamp DESC;

-- Failed loads
SELECT *
FROM dbo.pm_flex_load_log
WHERE load_status = 'FAILED'
ORDER BY load_timestamp DESC;

-- Load statistics by week
SELECT 
    source_ww,
    COUNT(*) as load_count,
    SUM(rows_loaded) as total_rows,
    AVG(execution_time_seconds) as avg_time_sec
FROM dbo.pm_flex_load_log
WHERE layer = 'COPPER'
GROUP BY source_ww
ORDER BY source_ww DESC;
```

## Troubleshooting

### Issue: File Not Found
```
PMFlexFileNotFoundError: No PM_Flex file found within last 4 weeks
```
**Solutions:**
1. Check network share path in `.env`
2. Verify you have network access
3. Check file naming: `PM_Flex.csv` (case-sensitive on some systems)
4. Increase `--max-weeks-back` parameter

### Issue: Schema Validation Failed
```
SchemaValidationError: Missing expected columns: ENTITY, FACILITY
```
**Solutions:**
1. Verify CSV format hasn't changed
2. Check if file is corrupted
3. Contact data provider about schema changes

### Issue: Database Connection Failed
```
DatabaseConnectionError: Cannot connect to SQL Server
```
**Solutions:**
1. Check SQL Server is running and accessible
2. Verify credentials in `.env`
3. Check firewall rules
4. Test connection: `python -c "from connectors import SQLServerConnector; SQLServerConnector()"`

### Issue: Altair Classification Missing
```
Warning: Could not add Altair classification
```
**Solutions:**
1. Check `data/altair_tools.csv` exists
2. Verify file format (ENTITY, ProcessAllowed columns)
3. Pipeline will continue with AltairFlag='UNKNOWN'

## Performance

Typical performance metrics:
- **File Size**: 20-50 MB
- **Row Count**: 50,000-200,000 rows
- **Load Time**: 30-120 seconds
- **Memory Usage**: ~500 MB peak

For large files (>100 MB):
- Consider increasing batch size in config
- Monitor SQL Server disk space
- Review index rebuild schedule

## Next Steps

After bronze layer completes:
1. Run Silver Layer ETL (enrichment and classification)
2. Run Gold Layer ETL (KPI aggregations)
3. Refresh Power BI dataset
