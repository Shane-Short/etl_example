"""
ETL modules for PM Flex pipeline.

This package contains the ETL logic for ingesting, transforming,
and loading PM_Flex data through Bronze, Silver, and Gold layers.
"""

__version__ = "1.0.0"
