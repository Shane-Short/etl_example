# Silver Layer ETL

The Silver layer enriches raw copper data with business logic, classifications, and aggregations.

## Components

### 1. PMTimingClassifier (`classification.py`)
Classifies PM timing and scheduled/unscheduled status.

**PM Timing Classification:**
- **Early**: < -15% of target
- **On-Time**: -15% to +15% of target  
- **Late**: +15% to +30% above target
- **Overdue**: > +30% above target

**Scheduled Classification:**
- Based on `DOWNTIME_TYPE` field
- Creates `scheduled_flag` (1=Scheduled, 0=Unscheduled)

### 2. ChronicToolAnalyzer (`classification.py`)
Identifies chronic tools using composite scoring.

**Chronic Score Calculation (0-100):**
- Unscheduled PM Rate (35%)
- PM Life Variance (25%)
- Downtime Hours (20%)
- Reclean Rate (10%)
- Sympathy PM Rate (10%)

**Severity Levels:**
- **Low**: Score 25-50
- **Medium**: Score 50-75
- **High**: Score 75-90
- **Critical**: Score > 90

### 3. PMFlexEnrichment (`enrichment.py`)
Main orchestration for all silver layer transformations.

**Creates 3 Silver Tables:**
1. `pm_flex_enriched` - Event-level enriched data
2. `pm_flex_downtime_summary` - Aggregated by site/CEID/WW
3. `pm_flex_chronic_tools` - Chronic tool analysis

**Also Populates:**
- `DimDate` - Intel WW calendar dimension

## Data Flow

```
┌─────────────────────────────┐
│ dbo.pm_flex_raw             │
│ (Copper Layer)              │
└─────────────┬───────────────┘
              │
              │ 1. Load Raw Data
              ▼
┌─────────────────────────────┐
│ PMFlexEnrichment            │
│                             │
│ ┌─────────────────────────┐│
│ │ PMTimingClassifier      ││
│ │  - PM timing (E/O/L/OD) ││
│ │  - Scheduled flag       ││
│ └─────────────────────────┘│
│                             │
│ ┌─────────────────────────┐│
│ │ ChronicToolAnalyzer     ││
│ │  - Calculate scores     ││
│ │  - Assign severity      ││
│ └─────────────────────────┘│
│                             │
│ + Parse work week           │
│ + Add PM cycle metrics      │
│ + Add downtime categories   │
│ + Calculate quality score   │
└─────────────┬───────────────┘
              │
              │ 2. Load to Silver
              ▼
┌─────────────────────────────┐
│ Silver Tables               │
│                             │
│ ┌─────────────────────────┐│
│ │ pm_flex_enriched        ││
│ │ (All original + new     ││
│ │  calculated columns)    ││
│ └─────────────────────────┘│
│                             │
│ ┌─────────────────────────┐│
│ │ pm_flex_downtime_summary││
│ │ (By Site/CEID/WW)       ││
│ └─────────────────────────┘│
│                             │
│ ┌─────────────────────────┐│
│ │ pm_flex_chronic_tools   ││
│ │ (By Entity)             ││
│ └─────────────────────────┘│
│                             │
│ ┌─────────────────────────┐│
│ │ DimDate                 ││
│ │ (Intel WW calendar)     ││
│ └─────────────────────────┘│
└─────────────────────────────┘
```

## New Columns Added to pm_flex_enriched

### Time-Based
- `ww_year` - Fiscal year (2025)
- `ww_number` - Week number (1-52)
- `fiscal_quarter` - Quarter (1-4)
- `fiscal_month` - Month (1-12)

### PM Timing
- `pm_timing_classification` - Early/On-Time/Late/Overdue
- `pm_life_vs_target` - Wafer count deviation from target
- `pm_life_vs_target_pct` - Percentage deviation

### Scheduled/Unscheduled
- `scheduled_flag` - 1=Scheduled, 0=Unscheduled
- `scheduled_category` - Scheduled/Unscheduled/Unknown

### PM Cycle Metrics
- `pm_cycle_efficiency` - Utilization percentage
- `pm_duration_outlier_flag` - 1=Outlier, 0=Normal
- `reclean_event_flag` - 1=Reclean, 0=Normal
- `sympathy_pm_flag` - 1=Sympathy PM, 0=Independent

### Downtime
- `downtime_category` - Combined Type + Class
- `downtime_primary_reason` - Primary root cause

### Quality
- `data_quality_score` - 0-100 based on completeness
- `enrichment_timestamp` - When enrichment occurred

## Running the Silver ETL

### Option 1: Incremental (Default)
```bash
# Process only new copper records
python -m etl.silver.run_silver_etl
```

### Option 2: Date Range
```bash
# Process specific date range
python -m etl.silver.run_silver_etl --start-date 2025-01-01 --end-date 2025-03-01
```

### Option 3: Full Refresh
```bash
# Truncate and reload all data
python -m etl.silver.run_silver_etl --full-refresh
```

### Option 4: Python Script
```python
from etl.silver.run_silver_etl import run_silver_etl

# Incremental load
stats = run_silver_etl()

# Full refresh
stats = run_silver_etl(full_refresh=True)

# Date range
stats = run_silver_etl(
    start_date='2025-01-01',
    end_date='2025-03-01',
    incremental=False
)
```

## Configuration

Key settings in `config/config.yaml`:

```yaml
etl:
  silver:
    incremental_load: true
    chronic_tool_threshold:
      unscheduled_pm_rate: 0.30  # 30%
      pm_life_variance: 0.40      # 40%
      min_pm_events: 5            # Minimum PMs

chronic_tools:
  severity_thresholds:
    low: 25
    medium: 50
    high: 75
    critical: 90
    
  score_weights:
    unscheduled_pm_rate: 0.35
    pm_life_variance: 0.25
    downtime_hours: 0.20
    reclean_rate: 0.10
    sympathy_pm_rate: 0.10

pm_timing:
  early_threshold: -15
  on_time_min: -15
  on_time_max: 15
  late_threshold: 15
  overdue_threshold: 30
```

## Monitoring Queries

### Check Enriched Data
```sql
-- Recent enriched records
SELECT TOP 100
    ENTITY,
    FACILITY,
    CEID,
    YEARWW,
    pm_timing_classification,
    scheduled_category,
    data_quality_score,
    enrichment_timestamp
FROM dbo.pm_flex_enriched
ORDER BY enrichment_timestamp DESC;

-- PM Timing Distribution
SELECT 
    pm_timing_classification,
    COUNT(*) as count,
    COUNT(*) * 100.0 / SUM(COUNT(*)) OVER() as percentage
FROM dbo.pm_flex_enriched
GROUP BY pm_timing_classification;

-- Scheduled vs Unscheduled
SELECT 
    scheduled_category,
    COUNT(*) as count,
    AVG(DOWN_WINDOW_DURATION_HR) as avg_downtime_hours
FROM dbo.pm_flex_enriched
GROUP BY scheduled_category;
```

### Check Downtime Summary
```sql
-- Summary by facility and week
SELECT TOP 20
    FACILITY,
    YEARWW,
    total_pm_events,
    unscheduled_pm_rate,
    avg_pm_life,
    total_downtime_hours
FROM dbo.pm_flex_downtime_summary
ORDER BY calculation_timestamp DESC;

-- Highest unscheduled PM rates
SELECT TOP 10
    FACILITY,
    CEID,
    YEARWW,
    unscheduled_pm_rate,
    total_pm_events
FROM dbo.pm_flex_downtime_summary
WHERE total_pm_events >= 5
ORDER BY unscheduled_pm_rate DESC;
```

### Check Chronic Tools
```sql
-- All chronic tools
SELECT 
    ENTITY,
    FACILITY,
    CEID,
    chronic_score,
    chronic_severity,
    unscheduled_pm_rate,
    pm_life_variance,
    total_pm_events
FROM dbo.pm_flex_chronic_tools
WHERE chronic_flag = 1
ORDER BY chronic_score DESC;

-- Chronic tools by severity
SELECT 
    chronic_severity,
    COUNT(*) as count,
    AVG(chronic_score) as avg_score,
    AVG(unscheduled_pm_rate) as avg_unscheduled_rate
FROM dbo.pm_flex_chronic_tools
WHERE chronic_flag = 1
GROUP BY chronic_severity
ORDER BY avg_score DESC;

-- Top 10 worst chronic tools
SELECT TOP 10
    ENTITY,
    FACILITY,
    chronic_score,
    chronic_severity,
    unscheduled_pm_count,
    total_pm_events,
    avg_downtime_hours_per_pm
FROM dbo.pm_flex_chronic_tools
WHERE chronic_flag = 1
ORDER BY chronic_score DESC;
```

## Business Rules

### PM Timing Classification
Based on actual wafer count vs. Median_Delta (target):

```
Deviation = (Actual - Target) / Target * 100

Early:    < -15%
On-Time:  -15% to +15%
Late:     +15% to +30%
Overdue:  > +30%
```

### Chronic Tool Criteria
A tool is flagged as chronic if:
1. Has at least 5 PM events, AND
2. Either:
   - Unscheduled PM rate > 30%, OR
   - PM life variance > 40%

### Chronic Score Formula
```
Score = (Unscheduled Rate × 35%) +
        (PM Variance × 25%) +
        (Downtime Hours × 20%) +
        (Reclean Rate × 10%) +
        (Sympathy PM Rate × 10%)
```

Each factor is normalized to 0-100 scale before weighting.

## Data Quality

The silver layer includes automatic data quality checks:

1. **Completeness Score**: Percentage of non-null critical columns
2. **Schema Validation**: Ensures expected columns exist
3. **Value Range Checks**: Validates rates are between 0-1
4. **Referential Integrity**: Verifies source_pm_flex_raw_id exists

## Performance

Typical execution metrics:
- **Input Rows**: 50,000-200,000 (from copper)
- **Enriched Rows**: Same as input
- **Summary Rows**: 500-2,000 (aggregated)
- **Chronic Tools**: 50-200 entities
- **Execution Time**: 60-180 seconds

Optimizations:
- Incremental processing (default)
- Vectorized pandas operations
- Batch loading to SQL
- Efficient groupby operations

## Troubleshooting

### Issue: No Data to Process
```
Warning: No new data to process
```
**Solution:** This is normal if bronze layer hasn't run recently. Check copper table for new records.

### Issue: Transformation Failed
```
TransformationError: Silver layer enrichment failed
```
**Solutions:**
1. Check logs for specific error
2. Verify copper data quality
3. Check for schema changes
4. Review config thresholds

### Issue: Chronic Score Calculation Error
```
Error calculating chronic scores
```
**Solutions:**
1. Check for divide-by-zero (need min_pm_events)
2. Verify variance calculations
3. Check for NULL values in key columns

## Next Steps

After silver layer completes:
1. Run Gold Layer ETL (KPI aggregations)
2. Refresh Power BI dataset
3. Review chronic tools report
4. Validate PM timing classifications
